
BioARC v2 (multilingual + partner map)

Files:
- index.html (home)
- about.html (map + partner list)
- bioarc_v2_styles.css
- bioarc_v2_i18n.js

Notes:
- Uses Leaflet via CDN and OpenStreetMap tiles.
- Requires BioARC_Logo_transparent.png in the same folder.
